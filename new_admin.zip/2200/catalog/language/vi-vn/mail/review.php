<?php
// Text
$_['text_subject']	= '%s - Xem xét sản phẩm';
$_['text_waiting']	= 'Bạn có chờ đợi đánh giá sản phẩm mới.';
$_['text_product']	= 'Sản phẩm: %s';
$_['text_reviewer']	= 'Reviewer: %s';
$_['text_rating']	= 'Đánh giá: %s';
$_['text_review']	= 'Nội dung đánh giá:';