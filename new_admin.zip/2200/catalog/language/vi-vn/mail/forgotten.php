<?php
// Text
$_['text_subject']  = '%s - Mật khẩu mới';
$_['text_greeting'] = 'Yêu cầu mật khẩu mới được gửi từ %s.';
$_['text_change'] = 'Mật khẩu mới của bạn là:';
$_['text_ip']       = 'Các IP được sử dụng để thực hiện yêu cầu này là: %s';