<?php
// Heading 
$_['heading_title'] = 'Mới nhất';

// Text
$_['text_tax']      = 'Phụ thuế:';