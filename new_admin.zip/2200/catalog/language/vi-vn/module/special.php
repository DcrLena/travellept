<?php
// Heading 
$_['heading_title'] = 'Khuyến mãi';

// Text
$_['text_tax']      = 'Phụ thuế:'; 