<?php
// Text
$_['text_captcha'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Nhập code vào ô bên dưới';

// Error
$_['error_captcha'] = 'Code không phù hợp với hình ảnh!';
