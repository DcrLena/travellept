<?php
// Text
$_['text_captcha'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Vui lòng hoàn tất việc xác nhận mã xác nhận bên dưới';

// Error
$_['error_captcha'] = 'Mã xác nhận không đúng!';
