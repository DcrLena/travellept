<?php
// Heading 
$_['heading_title']        = 'Tài khoản đại lý của tôi';

// Text
$_['text_account']         = 'Tài khoản';
$_['text_my_account']      = 'Tài khoản Đại lý';
$_['text_my_tracking']     = 'Thông tin theo dõi';
$_['text_my_transactions'] = 'Giao dịch của tôi';
$_['text_edit']            = 'Thay đổi thông tin tài khoản';
$_['text_password']        = 'Thay đổi mật khẩu';
$_['text_payment']         = 'Thay đổi phương thức thanh toán';
$_['text_tracking']        = 'Tùy chọn mã theo dõi đại lý';
$_['text_transaction']     = 'Xem lịch sử giao dịch';