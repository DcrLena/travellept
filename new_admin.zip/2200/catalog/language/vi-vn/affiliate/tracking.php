<?php
// Heading 
$_['heading_title']    = 'Đại lý theo dõi';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_description'] = 'Để đảm bảo bạn được thanh toán khi giới thiệu người mua bạn cần theo dõi người giới thiệu bằng cách đặt mã theo dõi trong đường dẫn đến gian hàng của chúng tôi. Bạn có thể sử dụng công cụ bên dưới để tạo đường dẫn đến trang web %s.';

// Entry
$_['entry_code']       = 'Mã theo dõi';
$_['entry_generator']  = 'Tạo liên kết theo dõi';
$_['entry_link']       = 'Liên Kết Theo Dõi:';

// Help
$_['help_generator']  = 'Gõ vào tên của một sản phẩm mà bạn muốn liên kết đến';