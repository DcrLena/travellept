<?php
// Text
$_['text_title']       = 'Nhận tại cửa hàng';
$_['text_description'] = 'Nhận tại cửa hàng';
?>