<?php
// Text
$_['text_title']                = 'Royal Mail';
$_['text_weight']               = 'Trọng lượng:';
$_['text_insurance']            = 'Bảo hiểm tối đa:';
$_['text_1st_class_standard']   = 'First Class Standard Post';
$_['text_1st_class_recorded']   = 'First Class Recorded Post';
$_['text_2nd_class_standard']   = 'Second Class Standard Post';
$_['text_2nd_class_recorded']   = 'Second Class Recorded Post';
$_['text_special_delivery_500']  = 'Special Delivery Next Day (&pound;500)';
$_['text_special_delivery_1000'] = 'Special Delivery Next Day (&pound;1000)';
$_['text_special_delivery_2500'] = 'Special Delivery Next Day (&pound;2500)';
$_['text_standard_parcels']     = 'Bưu kiện bình thường';
$_['text_airmail']              = 'Bưu phẩm chuyển bằng máy bay';
$_['text_international_signed'] = 'International Signed';
$_['text_airsure']              = 'Airsure';
$_['text_surface']              = 'Surface';
?>