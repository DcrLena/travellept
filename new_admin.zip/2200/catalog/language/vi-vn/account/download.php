<?php
// Heading 
$_['heading_title']   = 'Quản lý tải về';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_downloads']  = 'Tải về';
$_['text_empty']      = 'Bạn không có đơn hàng nào có thể tải về!';

// Column
$_['column_order_id']   = 'Thứ tự ID';
$_['column_name']       = 'Tên';
$_['column_size']       = 'Kích cỡ';
$_['column_date_added'] = 'Ngày đăng';