<?php
// Heading 
$_['heading_title']  = 'Thay đổi mật khẩu';

// Text
$_['text_account']   = 'Tài khoản';
$_['text_password']  = 'Mật khẩu';
$_['text_success']   = 'Thành công: Mật khẩu của bạn đã được cập nhật.';

// Entry
$_['entry_password'] = 'Mật Khẩu:';
$_['entry_confirm']  = 'Nhập Lại Mật Khẩu:';

// Error
$_['error_password'] = 'Mật khẩu phải từ 4 đến 20 kí tự!';
$_['error_confirm']  = 'Nhập lại mật khẩu không chính xác!';