<?php
// Text
$_['text_subject']	= 'Khách hàng liên hệ qua website';
$_['text_waiting']	= 'Có một liên hệ mới từ khách hàng';
$_['text_reviewer']	= 'Số lượng khách hàng: %s';
$_['text_rating']	= 'Đánh giá: %s';
$_['text_review']	= 'Nội dung liên hệ:';