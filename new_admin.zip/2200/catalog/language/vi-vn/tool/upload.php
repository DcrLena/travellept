<?php
// Text
$_['text_upload']    = 'Tập tin được tải lên thành công!';

// Error
$_['error_filename'] = 'Tên tập tin phải có từ 3 đến 64 ký tự!';
$_['error_filetype'] = 'Loại tập tin không hợp lệ!';
$_['error_upload']   = 'Tải lên yêu cầu!';
