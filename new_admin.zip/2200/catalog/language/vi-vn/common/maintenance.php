<?php
// Heading
$_['heading_title']     = 'Bảo Trì Hệ Thống';

// Text
$_['text_maintenance']  = 'Bảo Trì Hệ Thống';
$_['text_message']      = '<h1 style="text-align:center;">Chúng tôi đang tiến hàng bảo trì hệ thống định kì. <br/>Chúng tôi sẽ hoạt động lại sớm nhất có thể. Vui lòng quay lại sau.</h1>';
