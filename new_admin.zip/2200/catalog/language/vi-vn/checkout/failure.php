<?php
// Heading
$_['heading_title'] = 'Không thanh toán được!';

// Text
$_['text_basket']   = 'Giỏ hàng';
$_['text_checkout'] = 'Kiểm tra';
$_['text_failure']  = 'Không thanh toán được';
$_['text_message']  = '<p>Có vấn đề xử lý thanh toán của bạn và thứ tự đã không hoàn thành.</p>
					   <p>Lý do có thể là:</p>
					   <ul>
						  <li>Không đủ tiền</li>
						  <li>Không xác minh được</li>
					   </ul>
					   <p>Hãy thử để đặt hàng một lần nữa bằng cách sử dụng phương thức thanh toán khác nhau.</p>
					   <p>Nếu vấn đề vẫn tồn xin vui lòng liên hệ với <a href="%s"> chúng tôi </a> với các chi tiết đặt hàng bạn đang cố gắng để đặt . </p>
';
