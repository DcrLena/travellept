<?php
// Text
$_['text_success'] = 'Thành công: phiên API đã bắt đầu!';

// Error
$_['error_key']  = 'Cảnh báo: Không đúng API Key!';
$_['error_ip']   = 'Cảnh báo: IP của bạn %s không được phép truy cập vào API này!';