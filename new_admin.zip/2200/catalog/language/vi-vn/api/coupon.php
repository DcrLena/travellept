<?php
// Text
$_['text_success']     = 'Thành công: phiếu giảm giá của bạn đã được áp dụng!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào các API!';
$_['error_coupon']     = 'Cảnh báo: Phiếu giảm giá là không hợp lệ , hết hạn hoặc đạt giới hạn việc sử dụng nó!';