<?php
// Text
$_['text_success']     = 'Thành công: Bạn đã sửa đổi giỏ hàng của bạn!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào các API!';
$_['error_stock']      = 'Sản phẩm được đánh dấu bằng *** không có sẵn trong số lượng mong muốn hoặc không có trong kho!';
$_['error_minimum']    = 'Số lượng đặt hàng tối thiểu cho %s là %s!';
$_['error_store']      = 'Sản phẩm không thể mua từ hàng mà bạn đã chọn!';
$_['error_required']   = '%s cần thiết!';