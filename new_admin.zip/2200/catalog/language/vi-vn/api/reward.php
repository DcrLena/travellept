<?php
// Text
$_['text_success']     = 'Thành công: bạn giảm điểm thưởng đã được áp dụng!';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào các API!';
$_['error_reward']     = 'Cảnh báo: Vui lòng nhập số lượng điểm thưởng để sử dụng!';
$_['error_points']     = 'Cảnh báo: Bạn không có %s điểm thưởng!';
$_['error_maximum']    = 'Cảnh báo: số điểm tối đa có thể được áp dụng là %s!';