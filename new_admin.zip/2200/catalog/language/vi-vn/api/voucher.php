<?php
// Text
$_['text_success']     = 'Thành công: giảm giá phiếu quà tặng của bạn đã được áp dụng!';
$_['text_cart']        = 'Thành công: Bạn đã sửa đổi giỏ hàng của bạn!';
$_['text_for']         = 'Giấy chứng nhận quà tặng %s cho %s';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền truy cập vào các API!';
$_['error_voucher']    = 'Cảnh báo : Gift Voucher là không hợp lệ hoặc sự cân bằng đã được sử dụng hết!';
$_['error_to_name']    = 'Người nhận tên phải có từ 1 đến 64 ký tự!';
$_['error_from_name']  = 'Tên của bạn phải có từ 1 đến 64 ký tự!';
$_['error_email']      = 'E-Mail không hợp lệ!';
$_['error_theme']      = 'Bạn phải chọn một giao diện!';
$_['error_amount']     = 'Số tiền phải từ %s đến % s!';