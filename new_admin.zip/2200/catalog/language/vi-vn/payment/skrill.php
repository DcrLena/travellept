<?php
// Text
$_['text_title'] = 'Thẻ Credit Card / Thẻ Debit Card (Skrill)';