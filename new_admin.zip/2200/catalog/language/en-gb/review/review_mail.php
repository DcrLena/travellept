<?php
// Text
$_['text_subject']	= 'Store Review';
$_['text_waiting']	= 'You have a new store review waiting.';
$_['text_reviewer']	= 'Reviewer: %s';
$_['text_rating']	= 'Rating: %s';
$_['text_review']	= 'Review Text:';