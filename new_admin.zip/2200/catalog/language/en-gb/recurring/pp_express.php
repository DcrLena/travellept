<?php
// Text
$_['text_title']          = 'PayPal Express Checkout';
$_['text_canceled']       = 'Success: You have succesfully caneled this payment!';

// Button
$_['button_cancel']       = 'Cancel Recurring Payment';

// Error
$_['error_not_cancelled'] = 'Error: %s';
$_['error_not_found']     = 'Could not cancel recurring profile';